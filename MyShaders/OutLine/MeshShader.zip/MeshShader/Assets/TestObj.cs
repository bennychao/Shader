﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[ExecuteInEditMode]
public class TestObj : MonoBehaviour {

	public float ShowLine = -2;
	public Material ShowMaterail;
	public Material OldMaterail;
	// Use this for initialization
	void Start () {
		GetComponent<Renderer> ().sharedMaterial.SetFloat ("_CurShowLine", ShowLine );
		GetComponent<Renderer> ().sharedMaterial.SetVector ("_CenterPos", Vector3.zero);
		OldMaterail = GetComponent<Renderer> ().sharedMaterial;
	}
	
	// Update is called once per frame
	void Update () {
		GetComponent<Renderer> ().sharedMaterial.SetFloat ("_CurShowLine", ShowLine );
	}

	bool bShow = false;
	public void SwitchMat()
	{
		bShow = !bShow;
		GetComponent<Renderer> ().material = bShow ? ShowMaterail : OldMaterail;
	}
}
